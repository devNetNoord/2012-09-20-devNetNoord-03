﻿namespace AsynchronousConsole
{
    public enum DIConfigurationName
    {
        ThreadsAPM, 
        ThreadsEAP, 
        Tasks, 
        PLinq, 
        None, 
        Playground, 
        Illegal, 
        TPLDataflow, 
        Rx, 
        Synchronous, 
        SignalR, 
        AsyncAwait
    }
}