AsyncDemo
=========

Demo project for a talk on Asynchronous/prallell technolgies in .net

Currentlt very much a work in progress !

# uses :
## Installed on the dev machine 
	- VS 2010
	- .Net 4.0	
	- Nuget 
	- Asp.Net MVC 4.0
	
## In a shared lib folder:
	- TPL Dataflow

## Via Nuget (Auto restore when build)
	- Async CTP (version 3) 
	- Autofac 2.6
	- xUnit 1.9.1
	- Moq 4.0
	- Fluent Assertions 1.7
	- Reactive Extensions 2.0
	- SignalR 0.5.3

## Used when developing:
	- Resharper 7.1
	- xUnit plugin for Resharper
	- StyleCop 4.7.35.0 
