﻿namespace AsynchronousInterfaces
{
    public interface IRunner
    {
        void Run();
    }
}