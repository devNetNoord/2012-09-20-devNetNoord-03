namespace AsynchronousTools
{
    public interface ICommander
    {
        char WaitforSingleChar();
    }
}